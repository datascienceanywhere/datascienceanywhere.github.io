---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

**Feature Description**

<!-- Provide a clear and concise description of the feature -->

**Problem/Solution**

<!-- What problem will this feature solve? Or what new capability will it add? -->

**Alternatives Considered**

<!-- Have you considered any alternative solutions or workarounds? -->

**Additional Context**

<!-- Add any other context or screenshots about the feature request here -->
